# pipelines/

Orchestration code that chains the layers together: BMC deploy trigger ->
Proxmox install confirmation -> proxmoxer/Terraform VM provisioning ->
PA-VM bootstrap -> Ubuntu cloud-init clone.

Planned approach: Nautobot Job (jobs/xcc_deploy) triggers the BMC/install
step and stays fast/re-runnable; anything long-running or multi-stage
gets dispatched to an external orchestrator here (e.g. GitHub Actions
self-hosted runner or a standalone Python/Ansible pipeline), with status
written back to Nautobot custom fields on the device record.
