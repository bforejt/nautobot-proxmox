# ubuntu/

Cloud-init templates for the Ubuntu Desktop remote-access VM.

Planned contents:
- cloud-init/user-data.j2 — hostname, network (VLAN/IP from Nautobot),
  user provisioning
- Golden template build notes: bake desktop + remote-access tooling into
  one Proxmox template once, then clone + cloud-init per node rather than
  reinstalling desktop packages per deploy
