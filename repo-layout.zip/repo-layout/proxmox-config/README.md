# proxmox-config/

Post-install Proxmox VE configuration applied after the base OS is up:
storage config, VLAN/bridge mapping, Proxmox Datacenter Manager (PDM)
enrollment.

Planned contents:
- Bridge-per-VLAN mapping templates (parameterized by Nautobot VLAN data)
- PDM enrollment script/API calls (pending resolution of the 403 token
  permission scoping issue)
- Storage pool definitions
