# palo-vm/

VM-Series bootstrap package generation: init-cfg.txt, bootstrap.xml,
licensing/auth-code activation.

Planned contents:
- init-cfg.txt.j2 — mgmt IP/mask/gateway (from Nautobot), Panorama/SCM
  onboarding string
- bootstrap.xml.j2 — kept minimal: just enough to phone home to SCM,
  since policy config is centralized in SCM/Prisma Access rather than
  templated per-node
- ISO-packaging script (bootstrap files -> ISO, attached via Proxmox API
  at VM creation, same proxmoxer pattern as scm_migrate.py / the
  ESXi-to-Proxmox port)
- Auth code activation via SCM/CSP API (reuse patterns from the VM-Series
  relicensing runbook work)
