"""
xcc_client.py

Lenovo XClarity Controller (XCC) Redfish automation client.

Purpose: given a BMC IP + credentials + an HTTP(S) URL to a Proxmox VE
auto-install ISO, mount that ISO as virtual media, set one-time boot to CD,
and power-cycle the node. No USB sticks, no manual KVM interaction.

Designed to be called from a Nautobot job or orchestrator script — every
function takes explicit args (no globals) so it composes cleanly.

Tested against XCC2 Redfish implementations (ThinkEdge SE455 V3 generation).
Adjust RESOURCE paths if your XCC firmware exposes different Manager/System
IDs — call discover_resource_paths() first if unsure.
"""

from __future__ import annotations

import time
import logging
from dataclasses import dataclass
from typing import Optional

import requests
from requests.auth import HTTPBasicAuth

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("xcc_client")


class XCCError(RuntimeError):
    pass


@dataclass
class XCCSession:
    bmc_ip: str
    username: str
    password: str
    verify_tls: bool = False
    timeout: int = 30

    def __post_init__(self):
        self.base_url = f"https://{self.bmc_ip}"
        self.session = requests.Session()
        self.session.auth = HTTPBasicAuth(self.username, self.password)
        self.session.verify = self.verify_tls
        self.session.headers.update({"Content-Type": "application/json"})
        if not self.verify_tls:
            requests.packages.urllib3.disable_warnings()

        self._system_path: Optional[str] = None
        self._manager_path: Optional[str] = None
        self._vmedia_path: Optional[str] = None

    # ---------- low level ----------

    def _get(self, path: str) -> dict:
        r = self.session.get(f"{self.base_url}{path}", timeout=self.timeout)
        r.raise_for_status()
        return r.json()

    def _patch(self, path: str, body: dict) -> requests.Response:
        r = self.session.patch(f"{self.base_url}{path}", json=body, timeout=self.timeout)
        if r.status_code not in (200, 202, 204):
            raise XCCError(f"PATCH {path} failed: {r.status_code} {r.text}")
        return r

    def _post(self, path: str, body: dict) -> requests.Response:
        r = self.session.post(f"{self.base_url}{path}", json=body, timeout=self.timeout)
        if r.status_code not in (200, 202, 204):
            raise XCCError(f"POST {path} failed: {r.status_code} {r.text}")
        return r

    # ---------- discovery ----------

    def discover_resource_paths(self) -> None:
        """
        Walk the Redfish service root to find the ComputerSystem, Manager,
        and VirtualMedia collection paths. XCC generally exposes a single
        system/manager, but we don't hardcode indices in case that changes.
        """
        root = self._get("/redfish/v1/")

        systems = self._get(root["Systems"]["@odata.id"])
        self._system_path = systems["Members"][0]["@odata.id"]

        managers = self._get(root["Managers"]["@odata.id"])
        self._manager_path = managers["Members"][0]["@odata.id"]

        manager = self._get(self._manager_path)
        vmedia_collection = self._get(manager["VirtualMedia"]["@odata.id"])
        # Prefer a CD/DVD-capable member over a floppy/remote-disk member
        cd_candidates = [
            m["@odata.id"]
            for m in vmedia_collection["Members"]
        ]
        if not cd_candidates:
            raise XCCError("No VirtualMedia members found on this XCC")
        self._vmedia_path = self._select_cd_media(cd_candidates)

        log.info("System: %s", self._system_path)
        log.info("Manager: %s", self._manager_path)
        log.info("VirtualMedia: %s", self._vmedia_path)

    def _select_cd_media(self, candidates: list[str]) -> str:
        for path in candidates:
            detail = self._get(path)
            media_types = detail.get("MediaTypes", [])
            if "CD" in media_types or "DVD" in media_types:
                return path
        # fall back to first entry if type metadata is absent
        return candidates[0]

    # ---------- virtual media ----------

    def mount_iso(self, iso_url: str) -> None:
        if not self._vmedia_path:
            self.discover_resource_paths()

        action_path = f"{self._vmedia_path}/Actions/VirtualMedia.InsertMedia"
        body = {
            "Image": iso_url,
            "Inserted": True,
            "WriteProtected": True,
        }
        log.info("Mounting ISO %s -> %s", iso_url, self._vmedia_path)
        self._post(action_path, body)

    def eject_iso(self) -> None:
        if not self._vmedia_path:
            self.discover_resource_paths()
        action_path = f"{self._vmedia_path}/Actions/VirtualMedia.EjectMedia"
        log.info("Ejecting media at %s", self._vmedia_path)
        self._post(action_path, {})

    def verify_media_inserted(self) -> bool:
        detail = self._get(self._vmedia_path)
        return bool(detail.get("Inserted"))

    # ---------- boot control ----------

    def set_boot_once_to_cd(self) -> None:
        if not self._system_path:
            self.discover_resource_paths()
        body = {
            "Boot": {
                "BootSourceOverrideEnabled": "Once",
                "BootSourceOverrideTarget": "Cd",
            }
        }
        log.info("Setting one-time boot to CD on %s", self._system_path)
        self._patch(self._system_path, body)

    def power_action(self, action: str = "ForceRestart") -> None:
        """
        action: 'On', 'ForceOff', 'GracefulShutdown', 'ForceRestart',
                'GracefulRestart', etc. — matches Redfish ResetType enum.
        """
        if not self._system_path:
            self.discover_resource_paths()
        reset_path = f"{self._system_path}/Actions/ComputerSystem.Reset"
        log.info("Sending power action '%s' to %s", action, self._system_path)
        self._post(reset_path, {"ResetType": action})

    def get_power_state(self) -> str:
        detail = self._get(self._system_path)
        return detail.get("PowerState", "Unknown")

    # ---------- convenience: full trigger sequence ----------

    def deploy_from_iso(self, iso_url: str, poll_seconds: int = 5, poll_timeout: int = 120) -> None:
        """
        Full sequence: discover -> mount ISO -> set one-time CD boot -> reset.
        Confirms media is inserted before rebooting so we don't cycle the
        node into an empty boot device.
        """
        self.discover_resource_paths()
        self.mount_iso(iso_url)

        # confirm media actually attached before we reboot into it
        waited = 0
        while not self.verify_media_inserted():
            if waited >= poll_timeout:
                raise XCCError("Timed out waiting for virtual media to show Inserted=True")
            time.sleep(poll_seconds)
            waited += poll_seconds

        self.set_boot_once_to_cd()

        power_state = self.get_power_state()
        if power_state == "On":
            self.power_action("ForceRestart")
        else:
            self.power_action("On")

        log.info("Deploy trigger complete for %s — node is booting to %s", self.bmc_ip, iso_url)


if __name__ == "__main__":
    # Example standalone usage / smoke test.
    # In the Nautobot job this becomes: params come from the job form,
    # iso_url comes from the answer-file service keyed by BMC MAC or serial.
    import argparse

    parser = argparse.ArgumentParser(description="Trigger Proxmox auto-install via XCC Redfish virtual media")
    parser.add_argument("--bmc-ip", required=True)
    parser.add_argument("--username", required=True)
    parser.add_argument("--password", required=True)
    parser.add_argument("--iso-url", required=True, help="HTTP(S) URL to the auto-install ISO")
    parser.add_argument("--insecure", action="store_true", help="Skip TLS verification (self-signed BMC certs)")
    args = parser.parse_args()

    xcc = XCCSession(
        bmc_ip=args.bmc_ip,
        username=args.username,
        password=args.password,
        verify_tls=not args.insecure,
    )
    xcc.deploy_from_iso(args.iso_url)
