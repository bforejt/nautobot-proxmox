# Infra Automation — Proxmox / Palo Alto / Ubuntu Fleet Deployment

Automation for unattended deployment of the ThinkEdge SE455 V3 fleet:
Proxmox VE 9.x hypervisor, Palo Alto VM-Series firewall, and Ubuntu
Desktop (remote access), driven from a Nautobot Job with no USB sticks
or manual KVM interaction.

## Layout

```
.
├── bmc/               XCC/Redfish profiles, BIOS/RAID policy templates
├── proxmox-install/   answer.toml templates, firstboot hooks
├── proxmox-config/    post-install settings (bridges, VLANs, PDM enrollment)
├── palo-vm/           VM-Series bootstrap.xml/init-cfg.txt, licensing
├── ubuntu/            cloud-init templates for the desktop VM
├── pipelines/          orchestration code tying the layers together
└── jobs/
    └── xcc_deploy/     Nautobot Job: triggers BMC virtual-media deploy
        ├── __init__.py
        ├── xcc_client.py           Redfish client (no Nautobot deps —
        │                           testable standalone)
        └── deploy_proxmox_node.py  Nautobot Job wrapper (form, Secrets,
                                    logging)
```

Status: `jobs/xcc_deploy` is the first working piece — BMC/XCC Redfish
virtual media mount + one-time boot + power cycle, triggered from a
Nautobot Job form. Everything else is scaffolded as a placeholder
(`README.md` per folder describing planned contents) pending the
ISO/answer.toml strategy decision (see `proxmox-install/README.md`).

## Nautobot Git Repository setup

This repo is intended to be connected as a **Nautobot Git Repository**
(Extensibility -> Git Repositories -> Add) rather than mounted locally
via `JOBS_ROOT`:

- Repository URL: this repo (branch as configured)
- Provides: check **"jobs"**
- Nautobot auto-discovers Jobs under `jobs/` on sync — no docker-compose
  volume mounts or container restarts needed; push a commit and hit
  **Sync** (or let it run on schedule).

## Required Nautobot Secrets

Before running `jobs/xcc_deploy`, create two `Secret` objects (Secrets ->
Secrets -> Add), provider = Environment Variable:

| Secret name     | Points at env var (on celery_worker container) |
|------------------|--------------------------------------------------|
| `xcc_username`   | `XCC_USERNAME` (or your chosen name)              |
| `xcc_password`   | `XCC_PASSWORD` (or your chosen name)              |

The job looks these up by name (`xcc_username`, `xcc_password`) — see
`XCC_USERNAME_SECRET_NAME` / `XCC_PASSWORD_SECRET_NAME` at the top of
`deploy_proxmox_node.py` if you want to rename them.

## Enabling the job

Git-synced Jobs are disabled by default. After the first sync: Jobs ->
Jobs -> "Deploy Proxmox Node (SE455 V3)" -> edit -> check **Enabled**.
