"""
jobs/deploy_proxmox_node.py

Nautobot Job: triggers unattended Proxmox VE install on a Lenovo SE455 V3
node via XCC Redfish virtual media, using a pre-built/hosted auto-install
ISO (or an ISO whose answer.toml is fetched separately by MAC lookup).

This file intentionally contains NO Redfish logic itself — that lives in
xcc_client.py so it can be tested and reused outside of Nautobot. This
Job is just the Nautobot-facing form + orchestration + logging layer.

Install location: expects xcc_client.py to be importable, e.g. placed in
the same Nautobot "jobs" source path/App, or installed as part of a
Nautobot App (recommended for anything beyond a couple of files).
"""

from nautobot.apps.jobs import Job, StringVar, IPAddressVar, BooleanVar, register_jobs
from nautobot.extras.models import Secret

from .xcc_client import XCCSession, XCCError

# Names of the Secret objects created in Nautobot (Secrets -> Secrets).
# Each Secret's "provider" (Environment Variable, Text File, Vault, etc.)
# is configured on the Secret object itself in the UI — this Job doesn't
# need to know or care how/where the value is actually stored.
XCC_USERNAME_SECRET_NAME = "xcc_username"
XCC_PASSWORD_SECRET_NAME = "xcc_password"


class DeployProxmoxNode(Job):
    class Meta:
        name = "Deploy Proxmox Node (SE455 V3)"
        description = (
            "Triggers unattended Proxmox VE install on a Lenovo SE455 V3 via "
            "XCC Redfish virtual media — no USB stick required."
        )
        # No credentials collected via the form anymore -- they're pulled
        # from Nautobot Secrets at run time, so nothing sensitive flows
        # through job inputs/logs.
        has_sensitive_variables = False

    bmc_ip = IPAddressVar(
        label="BMC (XCC) IP Address",
        description="Management IP of the node's XClarity Controller",
    )

    iso_url = StringVar(
        label="Auto-Install ISO URL",
        description=(
            "HTTP(S) URL to the Proxmox auto-install ISO. If using the "
            "MAC-lookup answer-file pattern, this points at the generic "
            "ISO and the installer fetches answer.toml separately."
        ),
        default="http://provisioning.example.internal/isos/proxmox-ve-autoinstall.iso",
    )

    skip_tls_verify = BooleanVar(
        label="Skip BMC TLS verification",
        description="Enable for self-signed XCC certs (typical on isolated mgmt networks)",
        default=True,
    )

    def run(self, bmc_ip, iso_url, skip_tls_verify):
        self.logger.info(f"Starting Proxmox deploy trigger for BMC {bmc_ip}")

        try:
            bmc_username = Secret.objects.get(name=XCC_USERNAME_SECRET_NAME).get_value()
            bmc_password = Secret.objects.get(name=XCC_PASSWORD_SECRET_NAME).get_value()
        except Secret.DoesNotExist as e:
            self.logger.failure(
                f"Required Secret not found in Nautobot: {e}. "
                f"Expected Secrets named '{XCC_USERNAME_SECRET_NAME}' and '{XCC_PASSWORD_SECRET_NAME}'."
            )
            raise

        xcc = XCCSession(
            bmc_ip=str(bmc_ip),
            username=bmc_username,
            password=bmc_password,
            verify_tls=not skip_tls_verify,
        )

        try:
            xcc.discover_resource_paths()
            self.logger.info("Discovered Redfish resource paths successfully.")

            xcc.mount_iso(iso_url)
            self.logger.info(f"Mounted ISO: {iso_url}")

            if not xcc.verify_media_inserted():
                self.logger.warning("Media not confirmed inserted on first check — proceeding, xcc_client will poll.")

            xcc.set_boot_once_to_cd()
            self.logger.info("Set one-time boot override to CD.")

            power_state = xcc.get_power_state()
            action = "ForceRestart" if power_state == "On" else "On"
            xcc.power_action(action)
            self.logger.info(f"Sent power action '{action}'. Node is now booting to installer.")

        except XCCError as e:
            self.logger.failure(f"Redfish operation failed: {e}")
            raise
        except Exception as e:
            self.logger.failure(f"Unexpected error during deploy trigger: {e}")
            raise

        self.logger.success(
            f"Deploy trigger complete for {bmc_ip}. "
            "Node is installing — poll Proxmox mgmt IP separately to confirm completion."
        )


register_jobs(DeployProxmoxNode)
