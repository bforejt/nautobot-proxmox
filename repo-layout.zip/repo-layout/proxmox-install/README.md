# proxmox-install/

`answer.toml.j2` template(s) for Proxmox VE 9.x automated install, plus any
firstboot hook scripts (LACP bonding, VLAN-aware bridge setup) that run
after the base OS install completes.

Planned contents:
- answer.toml.j2 — parameterized by hostname, mgmt IP, disk selection
  (by model/serial, not /dev/sdX), network config
- firstboot/ — systemd unit + script(s) for LACP/bridge finalization
- Decision pending: single generic ISO + MAC-based answer.toml lookup
  service, vs. per-node pre-built ISO. Affects whether the pipeline layer
  needs an "ISO build" step before triggering jobs/xcc_deploy.
