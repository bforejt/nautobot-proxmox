# bmc/

XCC/Redfish profile templates and BIOS/RAID policy definitions for the
Lenovo ThinkEdge SE455 V3 fleet.

Status: logic currently lives in `jobs/xcc_deploy/xcc_client.py` as the
initial working implementation. As BIOS/RAID policy templating gets added
(vs. just virtual media + power control), split those Jinja2 templates
into this folder and have the job/pipeline layer read from here.
